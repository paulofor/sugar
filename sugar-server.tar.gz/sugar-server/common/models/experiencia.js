'use strict';

module.exports = function(Experiencia) {

};
