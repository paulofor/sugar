'use strict';

module.exports = function(Itemcusto) {

};
