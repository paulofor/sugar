./node_modules/.bin/lb-sdk server/server ~/sisacao5/AplicacoesAtivas/sisacao-angular/src/app/shared/sdk -d ng2web
